# SynQ AIVM Execution Integration

This document records the current SynQ-to-AIVM handoff. It is intentionally narrow: it describes what exists now and what must be finalized before SynQ contracts can be considered TESTNET-ready.

## Current Verified Handoff

- SynQ compiles to `quantumvm` bytecode with the `QVM\0` header.
- `synergy-aivm/runtime/aivm-core` exposes an initial `aivm_core::execution` module.
- The initial AIVM execution adapter accepts `synq-bytecode-v1` artifacts and executes them through the current SynQ `quantumvm` crate.
- AIVM returns an `ExecutionReceipt` with status, gas used, PQC gas used, return data, logs, and error text.
- AIVM also accepts `wasm-module-v1` artifacts for baseline WASM module loading.

## Non-Negotiable Completion Rule

SynQ is not complete when bytecode only runs in local compiler or `quantumvm` tests. SynQ is complete only when compiled SynQ artifacts execute through Synergy AIVM and can be deployed, called, traced, and verified through Synergy TESTNET.

## Artifact Envelope Draft

The current Rust draft is:

```text
ContractArtifact {
  format: "synq-bytecode-v1" | "wasm-module-v1",
  bytes: Vec<u8>,
  abi_json: Option<String>,
  compiler_version: Option<String>,
  source_hash: Option<String>
}
```

Before TESTNET use, this must become a stable serialized schema with:

- artifact format and version
- SynQ ABI version
- bytecode version
- compiler version
- source hash
- ABI hash
- metadata hash
- PQC backend profile
- gas profile
- supported AIVM host ABI version
- chain/network compatibility rules

## AIVM Runtime Decisions Still Open

- Decide whether `quantumvm` remains the embedded SynQ execution core inside AIVM or whether AIVM implements native SynQ opcode execution.
- Define persistent storage and contract address derivation.
- Define call data, return data, revert data, and event log encoding.
- Define AIVM host calls for storage, events, account context, block context, PQC precompiles, and AI model invocation.
- Define deterministic transcript commitments for contract execution and AI execution.
- Wire the AIVM receipt shape into Synergy TESTNET RPC.

## First TESTNET Smoke Target

The first live smoke should use one minimal SynQ contract that includes:

- one persistent state variable
- one read call
- one write call
- one event
- one PQC-gated path
- deterministic source hash and artifact hash

The smoke is successful only when CLI and SDK can compile the same source, submit the same AIVM artifact envelope, read the same receipt, and verify the deployed source hash.
