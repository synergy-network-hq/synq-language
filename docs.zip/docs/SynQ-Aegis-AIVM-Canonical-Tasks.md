# SynQ + aegis-pqsynq + Synergy-AIVM Canonical Task Register

Status date: 2026-05-26

Purpose: this is the single canonical task register for the SynQ language, the SynQ-specific `aegis-pqsynq` policy/verification adapter, the Synergy-AIVM execution runtime, and Project Rosetta network integration. A checkbox may be marked complete only when the proof field names a file, test, command, or live result that demonstrates completion.

## Source Merge

This register merges and supersedes task/checklist content from:

- User executive direction prompt from 2026-05-26.
- `/Volumes/xcode/synergy-network-projects/synq-language/checklist.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/SynQ-Project-Status-and-Execution-Backlog.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/PQSynQ-Completion-Execution-Plan.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/INTEGRATION_STATUS.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/audits/reports/PQSynQ-Foundation-Audit-2026-02-07.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/SynQ-Security-Audit-Manual.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/management/Definition-of-Done.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/management/SynQ-Release-Milestones.md`
- `/Volumes/xcode/synergy-network-projects/synq-language/docs/management/Weekly-Status-Template.md`
- `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/README.md`
- `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/`

## Completion Rules

- [x] CANON-001: Merge prompt and repo-local task sources into this canonical register. Proof: `rg -l "\[[ xX]\]|TODO|To-Do|To Do|to-do|todo|Checklist|checklist|Task List|Definition of Done|Milestone" /Volumes/xcode/synergy-network-projects/synq-language --glob '*.md' --glob '!target/**' --glob '!node_modules/**'` found the source documents listed above; this file now consolidates them.
- [x] CANON-002: Convert old checklist/status files into pointers to this register or clearly label them non-authoritative historical references. Proof: current canonical status notes were added to `checklist.md`, `INTEGRATION_STATUS.md`, `docs/PQSynQ-Completion-Execution-Plan.md`, `docs/SynQ-Project-Status-and-Execution-Backlog.md`, `docs/SynQ-Security-Audit-Manual.md`, `docs/management/Definition-of-Done.md`, `docs/management/SynQ-Release-Milestones.md`, and `docs/management/Weekly-Status-Template.md`; `docs/proof/SynQ-Aegis-AIVM-Proof-Log-2026-05-26.md` includes the `rg -n "Canonical status|canonical register|SynQ-Aegis-AIVM-Canonical" ...` output.
- [x] CANON-003: Keep a proof log for every completed item. Proof: `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/proof/SynQ-Aegis-AIVM-Proof-Log-2026-05-26.md` records command output excerpts for repo inspection, formatting, build, test, clippy, SDK, AIVM, and Rosetta verification commands run on 2026-05-26.
- [x] CANON-004: No item may be marked done based only on an older checklist claim. Proof: this register was updated only after current source changes and current commands in `docs/proof/SynQ-Aegis-AIVM-Proof-Log-2026-05-26.md`; live TESTNET/RPC items remain unchecked.

## Architecture Ownership

- [ ] ARCH-001: Enforce the target ownership model: SynQ owns language/compiler/CLI/SDK/artifacts, `aegis-pqsynq` owns SynQ-specific PQ policy and verification, Synergy-AIVM owns deterministic execution/receipts/gas/PQ-Gas. Partial: `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/architecture/aegis-pqsynq-vs-aegis-pqvm-integration.md` now defines the source-backed ownership model and identifies duplicate/prototype behavior, but the Testnet-Beta node path still does not call `aegis-pqsynq` for SynQ deploy/call gates.
- [ ] ARCH-002: Make `aegis-pqsynq` the hard dependency for SynQ deployment/call signing and AIVM security gates. Proof required: code paths call `aegis-pqsynq` for deploy/call verification; no duplicate crypto policy exists downstream.
- [x] ARCH-003: Decide whether standalone `aegis-pqsynq` wraps `aegis-pqc` or remains the authoritative SynQ-specific adapter over bundled `pqrust` crates. Proof: `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/architecture/aegis-pqsynq-vs-aegis-pqvm-integration.md` records that active `aegis-pqsynq` is a SynQ-specific adapter over bundled `pqrust` crates and does not wrap `aegis-pqvm`; `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/Cargo.toml` depends on workspace `pqrust-*` crates; no dependency change was required because the active source already matches the decision.
- [ ] ARCH-004: Decide whether AIVM embeds `quantumvm` as the canonical SynQ executor or replaces it with native AIVM SynQ execution. Proof required: decision record and tests proving a single opcode/runtime owner.
- [x] ARCH-005: Create `docs/architecture/repo-dependency-map.md`. Proof: file exists and maps SynQ -> aegis-pqsynq -> Synergy-AIVM -> chain 1264, plus Project Rosetta as a network settlement/verification consumer without circular dependencies.
- [x] ARCH-006: Create `docs/integration/synq-aegis-aivm-contract.md`. Proof: document defines compiler outputs, `aegis-pqsynq` verification inputs/outputs, AIVM preconditions, AIVM receipts, TESTNET node validation, and Rosetta boundary.
- [x] ARCH-007: Integrate Project Rosetta as a network settlement/verification consumer of Synergy TESTNET, not as a pooled bridge or wrapped-asset custodian. Proof: dependency map and `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/synergy-testnet-integration.md` preserve per-intent escrow, no pooled custody, no wrapped-asset default, and chain-1264 replay binding.

## Phase 0: Repo Reality Check And Baseline Audit

- [x] AUDIT-001: Audit `/Volumes/xcode/synergy-network-projects/synq-language`. Proof: `docs/audits/synq-language-audit.md` answers toolchain, build/test status, CI, APIs, missing files, undocumented assumptions, sensitive behavior, missing sensitive behavior, and end-to-end blockers.
- [x] AUDIT-002: Audit `/Volumes/xcode/synergy-network-projects/aegis-pqsynq`. Proof: `docs/audits/aegis-pqsynq-audit.md` answers the same questions and distinguishes standalone vs embedded copy.
- [x] AUDIT-003: Audit `/Volumes/xcode/synergy-network-projects/synergy-aivm`. Proof: `docs/audits/synergy-aivm-audit.md` answers the same questions and identifies the real Rust crates under `runtime/` and `verifier/`.
- [x] AUDIT-004: Audit `/Volumes/xcode/Synergy-Network-Projects/project-rosetta`. Proof: `docs/audits/project-rosetta-audit.md` answers the same questions and identifies prototype-only modules, mock adapters, and live-network blockers.
- [x] AUDIT-005: Verify required repo surface for each repo: `README.md`, `LICENSE`, `SECURITY.md`, `CONTRIBUTING.md`, `ARCHITECTURE.md`, `ROADMAP.md`, `CHANGELOG.md`, `.github/workflows/`, `tests/`, `examples/`, `docs/`. Proof: required-surface tables in the four audit files mark present/missing with paths.
- [x] AUDIT-006: Verify Rust/TypeScript/mixed manifests for each repo. Proof: toolchain sections in the four audit files list `Cargo.toml`, `Cargo.lock`, `package.json`, lockfiles, `src/`, tests, examples, crates, and SDKs where applicable.
- [x] AUDIT-007: Run current local verification gates. Proof: `docs/proof/SynQ-Aegis-AIVM-Proof-Log-2026-05-26.md`; `cargo fmt --check`, `cargo check --workspace --all-features --all-targets --locked`, and `cargo test --workspace --all-features --all-targets --locked` passed in SynQ; `cargo test -p aegis-pqsynq --all-features --all-targets --locked` passed; SynQ SDK `npm run typecheck` and `npm run test:integration` passed; AIVM `cargo test` passed in `runtime/aivm-core`, `runtime/aivm-node`, and `verifier/verifier-core`; Rosetta `cargo fmt --check`, `cargo test --workspace`, `cargo clippy --workspace --all-targets -- -D warnings`, SDK typecheck, and SDK tests passed. Standalone `aegis-pqsynq/aegis-pqsynq/pqsynq` direct `--manifest-path` test is blocked because that mirror lacks a workspace root for inherited dependencies.

## Shared Specification Set

- [x] SPEC-001: Create `specs/synq-language-spec.md` with `.synq` syntax, module/import rules, contracts, state, functions, visibility, mutability, events, errors, types, security declarations, host functions, gas semantics, and traps. Proof: file exists with v0.1 rules.
- [x] SPEC-002: Create `specs/synq-bytecode-spec.md` with magic bytes, bytecode version, target AIVM version, ABI hash, manifest hash, code hash, sections, instruction layouts, checksum, and versioning. Proof: file exists with concrete header and section layouts.
- [x] SPEC-003: Create `specs/synq-abi-spec.md` with canonical ABI encoding, method selectors, params, returns, events, errors, state schema, and Rust/TypeScript round-trip requirements. Proof: file exists with canonical ABI JSON and call-data encoding.
- [x] SPEC-004: Create `specs/synq-manifest-spec.md` with manifest version, contract name, compiler version, bytecode hash, ABI hash, security policy, required chain ID, AIVM version, permissions, host functions, and storage schema hash. Proof: file exists with required fields and rejection rules.
- [x] SPEC-005: Create `specs/synq-security-policy-spec.md` defining SynQ-specific PQ security rules owned by `aegis-pqsynq`. Proof: file exists with launch policy, algorithm IDs, and error families.
- [x] SPEC-006: Create `specs/synq-signing-payload-spec.md` with canonical binary layout, fixed domain tags, chain/network binding, nonce, expiration, algorithm ID, signer binding, and payload hash. Proof: file exists with binary layout and domain IDs.
- [x] SPEC-007: Create `specs/synq-address-format-spec.md` with internal address bytes, testnet HRP/prefix, checksum, public-key hash, network ID, algorithm ID, and test vectors. Proof: file exists with internal layout, checksum rule, HRP, and seed vector.
- [x] SPEC-008: Create `specs/synq-aivm-execution-spec.md` with bytecode loading, validation gates, host ABI, execution context, traps, state overlay, and deterministic scheduling. Proof: file exists with deploy/call flows and determinism rules.
- [x] SPEC-009: Create `specs/synq-receipt-spec.md` with deterministic receipt fields, canonical hash, status, gas, PQ-Gas, events, return data, trap code, and verification summary. Proof: file exists with receipt and event record fields.
- [x] SPEC-010: Create `specs/synq-pq-gas-spec.md` with costs for ML-DSA-65 verification, key/signature parsing, address derivation, payload hashing, manifest validation, deploy authorization, and call authorization. Proof: file exists with launch costs and failure semantics.
- [x] SPEC-011: Create `specs/synq-chain-1264-integration-spec.md` with `chain_id = 1264`, `network_name = "synergy-testnet"`, `address_hrp = "tsynq"`, default ML-DSA-65 policy, RPC surfaces, transaction envelopes, replay protection, and validator replay criteria. Proof: file exists with chain constants, deploy/call transaction fields, RPC requirements, and replay requirements.
- [ ] SPEC-012: Add canonical test vectors for bytecode, ABI, manifest, signing payload, address, receipt, and chain-1264 envelopes. Proof required: fixtures and tests consume them.

## aegis-pqsynq Policy Adapter

- [x] AEGIS-001: Add or verify `README.md`, `Cargo.toml`, `src/lib.rs`, `src/error.rs`, `src/policy.rs`, `src/algorithms.rs`, `src/domain.rs`, `src/payload.rs`, `src/address.rs`, `src/keys.rs`, `src/signature.rs`, `src/verifier.rs`, `src/serialization.rs`, `src/test_vectors.rs`, `tests/`, `examples/`, `docs/`, `.github/workflows/ci.yml`, `SECURITY.md`, `ARCHITECTURE.md`, and `INTEGRATION.md`. Proof: active embedded crate under `synq-language/aegis-pqsynq` and standalone copy under `aegis-pqsynq/aegis-pqsynq` contain these files; compile gate passed for the active embedded workspace.
- [x] AEGIS-002: README states that `aegis-pqsynq` is the SynQ-specific post-quantum security adapter, not a generic crypto playground. Proof: `aegis-pqsynq/pqsynq/README.md` and `aegis-pqsynq/ARCHITECTURE.md`.
- [x] AEGIS-003: Define public API `AegisSynQVerifier` with `verify_synq_transaction`, `verify_contract_deploy`, `verify_contract_call`, `derive_synq_address`, `canonicalize_signing_payload`, `validate_algorithm_policy`, and `verify_chain_domain`. Proof: `aegis-pqsynq/pqsynq/src/verifier.rs`; compile gate `cargo check -p aegis-pqsynq --all-features --all-targets --locked` passed.
- [x] AEGIS-004: Define canonical data types: `AlgorithmId`, `SecurityLevel`, `SignaturePurpose`, `DomainTag`, `ChainId`, `NetworkId`, `SynQAddress`, `SynQPublicKey`, `SynQPrivateKeyRef`, `SynQSignature`, `SynQSigningPayload`, `SynQTransactionEnvelope`, `ContractDeployEnvelope`, `ContractCallEnvelope`, `VerificationContext`, verified envelope types, and `AegisSynQError`. Proof: new modules in `aegis-pqsynq/pqsynq/src/`; compile gate passed.
- [x] AEGIS-005: Use enums with explicit numeric serialization values for algorithms and domains; avoid raw strings after parsing. Proof: `AlgorithmId::code`, `SignaturePurpose::code`, and `DomainTag::code` in `src/algorithms.rs` and `src/domain.rs`.
- [x] AEGIS-006: Launch policy allows ML-DSA-65 for transaction/deploy/call signatures unless a documented decision expands scope. Proof: `SynQSecurityPolicy::testnet_1264_policy()` in `src/policy.rs`.
- [x] AEGIS-007: Implement domain separation tags: `SYNQ_TX_V1`, `SYNQ_CONTRACT_DEPLOY_V1`, `SYNQ_CONTRACT_CALL_V1`, `SYNQ_VALIDATOR_MESSAGE_V1`, `SYNQ_AIVM_RECEIPT_V1`, `SYNQ_STATE_COMMITMENT_V1`, `SYNQ_WALLET_AUTH_V1`, `SYNQ_CROSS_CHAIN_MESSAGE_V1`. Proof: `DomainTag` in `src/domain.rs`.
- [x] AEGIS-008: Implement canonical signing payload serialization. Proof: `canonicalize_signing_payload` in `src/serialization.rs` uses custom binary layout with fixed magic, integer widths, length-prefixed network/signer bytes, numeric IDs, fixed domain codes, and no maps/floats/defaults; compile gate passed.
- [x] AEGIS-009: Implement payload hashing and canonicalization tests. Proof: `aegis-pqsynq/pqsynq/src/serialization.rs` exports `hash_signing_payload`; `aegis-pqsynq/pqsynq/tests/canonical_payload_tests.rs` covers deterministic canonical bytes, domain/chain-bound hash changes, and oversized length-prefixed field rejection; `cargo test -p aegis-pqsynq --all-features --all-targets --locked` passed.
- [x] AEGIS-010: Define and implement SynQ address derivation. Proof: `src/address.rs` derives 41-byte address with version, network ID, algorithm ID, SHA-256 public-key hash, checksum, and `tsynq1` debug rendering; compile gate passed.
- [x] AEGIS-011: Define `SynQSecurityPolicy` with allowlists, security level, domain/chain/nonce/expiration requirements, max signature size, max public key size. Proof: `src/policy.rs`.
- [x] AEGIS-012: Implement named policy presets: `devnet_policy`, `testnet_1264_policy`, `mainnet_candidate_policy`, and `strict_policy`. Proof: `src/policy.rs`.
- [x] AEGIS-013: Implement ML-DSA-65 signing/verification path for deploy/call envelopes. Proof: `aegis-pqsynq/pqsynq/src/signature.rs` dispatches `AlgorithmId::MlDsa65` to `Sign::mldsa65().verify`; `tests/synq_verifier_tests.rs` includes `valid_mldsa65_deploy_verifies` and `valid_mldsa65_call_verifies`; `cargo test -p aegis-pqsynq --all-features --all-targets --locked` passed.
- [x] AEGIS-014: Implement deploy verification: bytecode hash, manifest hash, ABI hash, signer, chain ID, network ID, domain, nonce, expiration, algorithm, signature. Proof: `aegis-pqsynq/pqsynq/src/verifier.rs::verify_contract_deploy`; `tests/synq_verifier_tests.rs::valid_mldsa65_deploy_verifies`; full `aegis-pqsynq` test gate passed.
- [x] AEGIS-015: Implement call verification: contract address, method selector, encoded args hash, caller, chain ID, network ID, domain, nonce, expiration, algorithm, signature. Proof: `aegis-pqsynq/pqsynq/src/verifier.rs::verify_contract_call`; `tests/synq_verifier_tests.rs::valid_mldsa65_call_verifies`; full `aegis-pqsynq` test gate passed.
- [x] AEGIS-016: Implement transaction verification and preserve structured security errors. Proof: `aegis-pqsynq/pqsynq/src/verifier.rs::verify_synq_transaction`; `tests/synq_verifier_tests.rs::transaction_dispatch_verifies_deploy` and `transaction_dispatch_preserves_security_errors`; full `aegis-pqsynq` test gate passed.
- [x] AEGIS-017: Add tests for valid ML-DSA signature, invalid signature, malformed public key, malformed signature, wrong chain, wrong domain, wrong algorithm, wrong signer, expired payload, oversized key/signature, non-canonical payload, deploy-as-call replay, call-as-wallet replay, testnet-vs-mainnet replay. Proof: `aegis-pqsynq/pqsynq/tests/synq_verifier_tests.rs` now covers valid deploy/call, invalid signature, malformed public key, malformed signature, wrong chain, wrong domain, wrong algorithm, wrong signer, expired payload, oversized public key, oversized signature, deploy-as-call replay, call-as-wallet replay, testnet-vs-mainnet replay, transaction dispatch, and structured error preservation; `aegis-pqsynq/pqsynq/tests/canonical_payload_tests.rs` covers deterministic canonical bytes and rejection of non-canonical oversized length-prefixed fields; `cargo test -p aegis-pqsynq --test synq_verifier_tests --test synq_deploy_vector_tests --locked` passed with 17 verifier tests and 1 vector replay test.
- [x] AEGIS-018: Add known-answer vector files: `ml_dsa_65_valid_deploy.json`, `ml_dsa_65_invalid_signature.json`, `ml_dsa_65_wrong_chain.json`, `ml_dsa_65_wrong_domain.json`. Proof: files exist under `aegis-pqsynq/pqsynq/tests/vectors/`; `aegis-pqsynq/pqsynq/tests/synq_deploy_vector_tests.rs` consumes all four fixtures; `cargo test -p aegis-pqsynq --test synq_deploy_vector_tests --locked` passed; `rg -n "secret|private|sk|seed" aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_*.json` returned no matches.
- [ ] AEGIS-019: Add fuzzing for payload decoder.
- [x] AEGIS-020: Add examples: generate keypair, sign/verify deploy, sign/verify call, derive address. Proof: `aegis-pqsynq/pqsynq/examples/synq_deploy_call_verifier.rs` generates an ML-DSA-65 keypair, derives a `tsynq` testnet address, signs/verifies a chain-1264 deploy envelope, and signs/verifies a chain-1264 call envelope; `cargo run -p aegis-pqsynq --example synq_deploy_call_verifier --locked` printed `chain_id=1264`, `network=synergy-testnet`, `deploy=verified`, and `call=verified`.
- [ ] AEGIS-021: CI runs `cargo fmt --check`, clippy with warnings denied, tests, audit, deny, and docs; TypeScript bindings run install/lint/typecheck/test if present.
- [ ] AEGIS-022: Keep existing PQ substrate gates green: pinned vectors, optional official NIST KAT strict mode, no-std/wasm/WASI gates, compliance report, zeroization, side-channel posture, dependency pinning.
- [x] AEGIS-BLOCKER-001: Fix existing PQClean/PQRust FFI SIGSEGV on local ML-DSA/KEM keygen tests. Proof: `TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test -p aegis-pqsynq --all-features --all-targets --locked` passed on 2026-05-26, including `tests/basic_tests.rs`, `tests/kat_tests.rs`, `tests/nist_vector_replay_tests.rs`, `tests/synq_verifier_tests.rs`, and ML-DSA-65 benchmark paths.

## SynQ Language, Compiler, CLI, SDK

- [ ] LANG-001: Set repo structure policy for Rust or TypeScript first layout. Proof required: actual layout is documented and stale aspirational layout is removed.
- [ ] LANG-002: Freeze v1 `.synq` language grammar and make docs match parser grammar exactly.
- [ ] LANG-003: Implement lexer/token coverage: identifiers, keywords, integer/string/byte/bool literals, operators, delimiters, comments, doc comments, attributes, EOF, invalid character, unterminated string, large integer, reserved keyword tests.
- [ ] LANG-004: Implement parser coverage: module declarations, imports, contract declarations, state fields, functions, params, returns, blocks, statements, expressions, assignments, calls, member access, security blocks, events, errors, and negative fixtures.
- [ ] LANG-005: Define AST nodes with source spans: `SourceFile`, `ModuleDecl`, `ImportDecl`, `ContractDecl`, `StateDecl`, `FunctionDecl`, `Parameter`, `TypeRef`, `Block`, `Statement`, `Expression`, `SecurityDecl`, `EventDecl`, `ErrorDecl`.
- [ ] LANG-006: Complete semantic analysis: symbol table, scope resolution, duplicate declarations, imports, contract members, function lookup, state lookup, visibility, security declaration validation.
- [ ] LANG-007: Complete type checker for conservative deterministic types: bool, unsigned/signed integers, bytes, bytes32, address, string, arrays, maps if retained; floats stay unsupported.
- [ ] LANG-008: Implement compiler pipeline: source -> lexer -> parser -> AST -> semantic analysis -> type checking -> IR -> optimizer -> bytecode -> ABI -> manifest.
- [ ] LANG-009: Introduce formal SynQ IR with golden tests.
- [ ] LANG-010: Implement bytecode emitter and formal instruction set: `NOP`, `PUSH_U64`, `PUSH_BYTES`, `LOAD_STATE`, `STORE_STATE`, `LOAD_LOCAL`, `STORE_LOCAL`, `ADD_U64`, `SUB_U64`, `MUL_U64`, `DIV_U64`, comparisons, jumps, `CALL`, `RET`, `EMIT`, `TRAP`, `HOST_CALL`.
- [ ] LANG-011: Define deterministic gas cost for every instruction.
- [ ] LANG-012: Generate ABI artifact with contract, methods, params, returns, events, errors, state schema, and security requirements.
- [ ] LANG-013: Generate manifest artifact with version, contract name, compiler version, bytecode hash, ABI hash, security policy, signature algorithm, chain ID, AIVM version, permissions, host functions, storage schema hash.
- [ ] LANG-014: Implement `Counter.synq` example and canonical artifact outputs.
- [ ] LANG-015: Implement CLI commands: `synq init`, `synq build`, `synq check`, `synq test`, `synq fmt`, `synq abi`, `synq manifest`, `synq deploy --chain 1264`, `synq call`, `synq keygen`, `synq sign-deploy`, `synq verify-deploy`, `synq simulate`.
- [ ] LANG-016: Ensure CLI crypto-specific commands call `aegis-pqsynq`, not local duplicate crypto logic.
- [ ] LANG-017: Add compiler golden tests, parser/AST snapshots, semantic/type tests, bytecode/ABI/manifest golden tests, diagnostic tests, CLI smoke tests, AIVM execution tests, and `aegis-pqsynq` integration tests.
- [ ] LANG-018: Implement imports/modules or remove them from v1 docs.
- [ ] LANG-019: Implement diagnostics with source locations and actionable messages.
- [ ] LANG-020: Implement SDK key provider, transaction signing, ABI-generated clients, event parsing, contract deployment helpers, wallet integration, and Rust/TypeScript vector parity.
- [ ] LANG-021: Remove or clearly label Solidity compatibility output if it is not production deployable.
- [ ] LANG-022: Add WebAssembly/browser bindings if still in scope.

## Synergy-AIVM Runtime

- [ ] AIVM-001: Verify AIVM repo structure and create missing docs/status files. Proof required: audit paths and required repo surface table.
- [ ] AIVM-002: Create AIVM execution spec and bytecode/artifact envelope spec.
- [ ] AIVM-003: Implement bytecode loader, bytecode validator, instruction decoder, stack engine, memory model, local variables, call frames, state overlay, gas meter, PQ-Gas meter, host function registry, trap handler, and receipt builder.
- [ ] AIVM-004: Define `ExecutionContext` with chain ID, network ID, block height/timestamp, tx hash, caller, contract address, gas/PQ-Gas limits, and security policy.
- [ ] AIVM-005: Prohibit nondeterministic runtime behavior: wall-clock time, nondeterministic randomness, network I/O, filesystem I/O, host-specific behavior.
- [ ] AIVM-006: Implement deployment verification gates: bytecode format/version, target AIVM version, manifest hash, ABI hash, security requirements, deploy signer through `aegis-pqsynq`, chain ID, domain, nonce, permissions. Partial: local TESTNET source contains AIVM deploy runtime scaffolding in `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/aivm/runtime.rs`, but the RPC deployment handler is commented out and not wired to `aegis-pqsynq`.
- [ ] AIVM-007: Implement contract-call gates: caller signature through `aegis-pqsynq`, call domain, chain ID, nonce, ABI method existence, visibility, args encoding, PQ-Gas budget. Partial: local TESTNET source contains AIVM execute runtime scaffolding and `synergy_call`, but AIVM RPC execution is commented out and canonical `aegis-pqsynq` call verification is not wired.
- [ ] AIVM-008: Implement deterministic receipt generation and canonical hashing, with optional validator-attestable receipt flow. Partial: `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/execution.rs` defines deterministic `TransactionReceipt`, `ExecutionResult`, `state_root_after`, and `receipt_root`; this is not yet proven as the enabled AIVM deploy/call receipt path.
- [ ] AIVM-009: Define state model: global state root, contract namespace, key-value storage, overlay, commit-on-success, rollback-on-trap.
- [ ] AIVM-010: Implement two metering lanes: gas for compute/memory/storage and PQ-Gas for PQ verification/key/signature operations.
- [ ] AIVM-011: Define AIVM error taxonomy: bytecode, manifest, ABI, verification, gas, PQ-Gas, runtime trap, state, host function, receipt, internal invariant. Partial: specs define the desired taxonomy; inspected local TESTNET runtime does not expose a complete AIVM error enum for these categories.
- [ ] AIVM-012: Preserve structured `aegis-pqsynq` security errors instead of flattening to generic invalid transaction. Blocked: inspected local TESTNET path uses `aegis-pqvm` admission and does not yet call `aegis-pqsynq` for node/AIVM security gates; `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/architecture/aegis-pqsynq-vs-aegis-pqvm-integration.md` defines the required `AegisSynQError::code()` preservation boundary.
- [ ] AIVM-013: Add tests: valid bytecode, invalid magic/version/instruction/jump, stack underflow, gas/PQ-Gas exhaustion, wrong manifest hash, invalid deploy signature, wrong chain/domain, Counter execution, state rollback, deterministic receipt, replay same transaction identical receipt.
- [ ] AIVM-014: Integrate deterministic AI/model execution calls only after model IDs, inputs, outputs, transcript hashing, gas, failure behavior, and verifier policy are specified.
- [ ] AIVM-015: Replace placeholder node binary with operational runtime server behavior if AIVM node remains in scope.

## Chain 1264 / Synergy TESTNET

- [x] NET-001: Define chain 1264 config: chain ID, network name, address HRP, default signature algorithm, AIVM version, SynQ bytecode version. Proof: `/Volumes/xcode/Synergy-Network-Projects/synq-language/specs/synq-chain-1264-integration-spec.md` defines the SynQ target constants; `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs` defines `SYNERGY_TESTNET_V2_CHAIN_ID = 1264` and `SYNERGY_TESTNET_V2_NETWORK_ID = "synergy-testnet-v2"`; `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/integration/testnet-beta-source-inventory-2026-05-26.md` records the local source evidence.
- [x] NET-002: Define transaction envelope, deployment transaction, and contract-call transaction. Proof: `/Volumes/xcode/Synergy-Network-Projects/synq-language/specs/synq-chain-1264-integration-spec.md` defines canonical SynQ deploy/call envelope fields; `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/transaction.rs`, `src/rpc/rpc_server.rs`, `src/aegis_tx_tool.rs`, and `src/synergy_types.rs` define current Synergy RPC and Aegis transaction envelope formats; source inventory records field mappings.
- [ ] NET-003: Implement node validation flow for deploy transactions: decode, chain ID, type, nonce, fee, bytecode hash, manifest hash, `aegis-pqsynq` verify, AIVM load/init, receipt, state commit, index contract/ABI/manifest/receipt. Partial: local TESTNET source implements chain-bound `synergy_sendTransaction` and `synergy_submitAegisTransaction` admission through `aegis-pqvm`, but canonical SynQ deploy validation through `aegis-pqsynq` and enabled AIVM deployment are not present; see source inventory.
- [ ] NET-004: Implement node validation flow for contract calls: decode, chain ID, nonce, fee, `aegis-pqsynq` verify, load contract, execute method, receipt, state commit, index receipt/events. Partial: local TESTNET source classifies non-empty transaction `data` as contract-call gas and exposes `synergy_call`, but canonical SynQ call verification through `aegis-pqsynq` and enabled AIVM execution are not present; see source inventory.
- [ ] NET-005: Expose RPCs: `synq_estimateGas`, `synq_estimatePqGas`, `synq_deployContract`, `synq_callContract`, `synq_getContract`, `synq_getReceipt`, `synq_getEvents`, `synq_verifyPayload`, `synq_getSecurityPolicy`; `synq_compile` only if node intentionally includes compiler. Partial: local source exposes `synergy_*` methods including `synergy_estimateGas`, `synergy_getReceipt`, `synergy_getTransactionReceipt`, `synergy_sendTransaction`, `synergy_submitAegisTransaction`, and `synergy_submitAegisDagTransaction`; future `synq_*` methods are not implemented.
- [ ] NET-006: Index explorer fields: contract address, deployer, algorithm ID, bytecode hash, manifest hash, ABI hash, gas, PQ-Gas, domain tag, chain ID, receipt hash, events, status, trap code. Partial: local receipt/RPC source exposes `contractAddress`, `from`, gas fields, status, logs, and chain identity; algorithm ID, bytecode/manifest/ABI hashes, PQ-Gas, domain tag, and trap code are not present in the inspected receipt shape.
- [ ] NET-007: Verify active TESTNET RPC method matrix with example request/response payloads. Partial: source-backed method matrix is recorded in `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/integration/testnet-beta-source-inventory-2026-05-26.md`; local qRPC probes against `127.0.0.1:5640` and `127.0.0.1:5641` found no listener, so active endpoint request/response smoke proof was not captured.
- [ ] NET-008: Run deterministic replay test across validator nodes and prove identical state root and receipt hash.

## Project Rosetta Network Integration

- [x] ROSETTA-001: Inspect `/Volumes/xcode/Synergy-Network-Projects/project-rosetta` before implementation. Proof: filesystem inventory found Rust workspace crates, TS SDK, docs, EVM/Solana/Move contract directories, test vectors, examples, and no `.git` repo at that path.
- [x] ROSETTA-002: Define the first Synergy TESTNET domain profile in Rust. Proof: `crates/rosetta-core/src/domain.rs` defines `SYNERGY_TESTNET_CHAIN_ID = "1264"`, `SYNERGY_TESTNET_NETWORK = "synergy-testnet"`, `DomainId::synergy`, and `DomainId::synergy_testnet()`.
- [x] ROSETTA-003: Define the first Synergy TESTNET domain profile in the TypeScript SDK. Proof: `sdk/typescript/src/route.ts` defines `SYNERGY_TESTNET_CHAIN_ID`, `SYNERGY_TESTNET_NETWORK`, `synergy`, and `synergyTestnet()`.
- [x] ROSETTA-004: Add tests proving the Synergy TESTNET profile resolves to chain 1264. Proof: Rust unit test in `crates/rosetta-core/src/domain.rs` and TypeScript test `sdk/typescript/test/synergy-domain.test.ts`; `cargo test --workspace` passed and `corepack pnpm --filter @synergy/rosetta-sdk test` passed with 5 tests.
- [x] ROSETTA-005: Add a Rosetta/Synergy TESTNET integration document. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/synergy-testnet-integration.md`.
- [x] ROSETTA-006: Add a Synergy TESTNET adapter interface that consumes chain-1264 receipts without submitting live transactions. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/crates/rosetta-verification/src/synergy.rs` defines `SynergyTestnetReceiptVerifier` and `SynergyTestnetReceipt`; no transaction submission API is present.
- [x] ROSETTA-007: Add a mock Synergy TESTNET receipt verifier for deterministic local tests. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/crates/rosetta-verification/src/synergy.rs` defines `MockSynergyTestnetReceiptVerifier`; `cargo test --workspace` passed with 5 `synergy::tests::*` tests.
- [x] ROSETTA-008: Map Rosetta settlement artifacts to Synergy TESTNET transaction/receipt fields after live RPC shape is confirmed. Proof: `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/rpc/rpc_server.rs` defines `synergy_getReceipt` and `synergy_getTransactionReceipt` fields; `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/crates/rosetta-verification/src/synergy.rs` defines `SynergyRpcReceipt` and maps it into `SynergyTestnetReceipt`; `cargo test -p rosetta-verification synergy::tests -- --nocapture` passed in both Project Rosetta copies with `real_synergy_get_receipt_shape_maps_to_rosetta_receipt`.
- [x] ROSETTA-009: Define how intent IDs, scope digests, replay domains, and audit receipt hashes are indexed on Synergy TESTNET. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/synergy-testnet-integration.md` contains the indexing mapping; `SynergyRosettaIndexRecord` and `build_synergy_rosetta_index_record` are implemented in `crates/rosetta-verification/src/synergy.rs`.
- [x] ROSETTA-010: Define how `aegis-pqsynq` validates SynQ/Synergy signatures used by Rosetta intents or escrow authorizations. Proof: `/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/architecture/aegis-pqsynq-vs-aegis-pqvm-integration.md` defines the split: `aegis-pqsynq` validates inner SynQ deploy/call authorization and `aegis-pqvm` validates outer Synergy transaction/DAG admission before Rosetta consumes finalized receipts; Project Rosetta must not own duplicate signature policy.
- [x] ROSETTA-011: Define whether Synergy-AIVM executes Rosetta verification logic or only indexes/consumes Rosetta settlement artifacts. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/synergy-testnet-integration.md` states Rosetta only consumes/indexes Synergy TESTNET receipt artifacts for the prototype; source inventory records that local AIVM RPC deploy/execute handlers are temporarily disabled.
- [x] ROSETTA-012: Run a local mock Synergy route scenario with deterministic audit receipt output. Proof: `crates/rosetta-verification/src/synergy.rs::mock_synergy_route_scenario_outputs_deterministic_index_record`; `cargo test -p rosetta-verification synergy::tests -- --nocapture` passed in both `/Volumes/xcode/Synergy-Network-Projects/project-rosetta` and `/Users/devpup/Desktop/Testnet-Beta/project-rosetta`.
- [ ] ROSETTA-013: Run a live chain-1264 read-only smoke test against confirmed RPC methods.
- [ ] ROSETTA-014: Design a guarded testnet submit path for non-production value only after read-only verification passes.
- [x] ROSETTA-015: Keep legal/IP boundaries, prototype warnings, per-intent escrow, no pooled bridge, and no wrapped-asset default visible in code/docs. Proof: `/Volumes/xcode/Synergy-Network-Projects/project-rosetta/README.md`, `docs/legal-ip-boundaries.md`, `docs/prototype-limitations.md`, `docs/synergy-testnet-integration.md`, and `contracts/evm/src/RosettaEscrow.sol` preserve internal prototype, per-intent escrow, no pooled custody, and no wrapped-asset default language; new `crates/rosetta-verification/src/synergy.rs` consumes receipts only and adds no live submit path.

## Developer Experience

- [ ] DX-001: Implement happy path: `synq init counter`, `synq build`, `synq keygen --algorithm ml-dsa-65 --network testnet`, `synq deploy --chain 1264`, `synq call Counter.increment`, `synq call Counter.get`.
- [ ] DX-002: Implement project template with `synq.toml`, `contracts/Counter.synq`, tests, deploy script, and ignored keys directory.
- [ ] DX-003: Implement `synq.toml` package/compiler/network/security config.
- [ ] DX-004: Create TESTNET deployment guide and troubleshooting guide.
- [ ] DX-005: Add API reference, tutorials, best practices, migration notes, common patterns, and example projects after behavior is implemented.
- [ ] DX-006: Add LSP, syntax highlighting, autocomplete, go-to-definition, diagnostics, formatting, IDE extensions, debugger, bytecode viewer, gas profiler, and verification tools if kept in roadmap.

## Security, QA, Release, And Governance

- [ ] SEC-001: Create or refresh `SECURITY.md`, `docs/security/threat-model.md`, `docs/security/algorithm-policy.md`, `docs/security/domain-separation.md`, `docs/security/canonical-serialization.md`, `docs/security/key-address-format.md`, and `docs/security/gas-and-pq-gas.md`.
- [ ] SEC-002: Cover threats: replay across chains/domains, malformed keys/signatures, oversized DoS, algorithm downgrade, unsupported algorithm acceptance, non-canonical payload ambiguity, ABI/manifest/bytecode mismatch, PQ-Gas underpricing/exhaustion, nonce collisions, rollback failure, receipt nondeterminism, host nondeterminism, compiler/runtime mismatch.
- [ ] SEC-003: Enable fuzzing for parser, bytecode decoder, payload decoder, ABI decoder, and VM execution.
- [ ] SEC-004: Complete malformed input tests, signature vectors, gas/PQ-Gas abuse tests, replay tests, wrong-chain/domain tests, and protected branch CI.
- [ ] SEC-005: No unsafe Rust unless justified and audited.
- [ ] SEC-006: Prepare external cryptographic review, VM/runtime audit, consensus replay audit, compiler/runtime equivalence review, stable test vectors, and versioned upgrade process before mainnet candidate.
- [ ] QA-001: Maintain full local gate: formatting, clippy, tests, SDK typecheck/tests, AIVM crates, examples, security fixtures, docs link checks.
- [ ] QA-002: Add CI profiles: default, PQC strict, AIVM integration, SDK, and TESTNET smoke.
- [ ] QA-003: Add coverage reporting, performance benchmarks, property tests, and release-quality gate.
- [ ] REL-001: Version compiler, ABI, bytecode, manifest, AIVM, SDK, and `aegis-pqsynq` policies together with compatibility matrix.
- [ ] REL-002: Package CLI and SDK with reproducible checksums.
- [ ] REL-003: Maintain changelog, known limitations, audit evidence package, and release sign-off.

## End-To-End Demo Definition Of Done

- [ ] DEMO-001: Developer writes `contracts/Counter.synq`.
- [ ] DEMO-002: `synq build` emits bytecode, ABI, and manifest.
- [ ] DEMO-003: `synq keygen` creates a testnet ML-DSA-65 identity.
- [ ] DEMO-004: `synq deploy` creates a canonical deployment payload.
- [ ] DEMO-005: `aegis-pqsynq` signs/verifies deployment payload.
- [ ] DEMO-006: AIVM validates bytecode and manifest.
- [ ] DEMO-007: AIVM executes deployment/init.
- [ ] DEMO-008: Deterministic receipt is generated.
- [ ] DEMO-009: `synq call Counter.increment` creates canonical call payload.
- [ ] DEMO-010: `aegis-pqsynq` verifies call payload.
- [ ] DEMO-011: AIVM executes the method.
- [ ] DEMO-012: `synq call Counter.get` returns expected value.
- [ ] DEMO-013: Gas and PQ-Gas are reported.
- [ ] DEMO-014: Replaying the same block on another node produces the same state root and receipt hash.

## Historical / Future Roadmap Items Kept From Older Lists

- [ ] FUTURE-001: Complete optional PQC algorithm matrix beyond launch ML-DSA-65 only when policy and consensus risk are explicitly accepted.
- [ ] FUTURE-002: Add batch verification precompiles.
- [ ] FUTURE-003: Add hardware acceleration hooks such as HSM/TPM after software semantics are stable.
- [ ] FUTURE-004: Add PQC-based validator/block/governance signatures only when consensus design requires them.
- [ ] FUTURE-005: Add faucet, explorer, monitoring dashboards, developer/community programs, bug bounty, benchmarks, case studies, load testing, capacity planning, bridges, oracles, and ecosystem programs after core TESTNET deploy/call works.
