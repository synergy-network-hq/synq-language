# SynQ / aegis-pqsynq / Synergy-AIVM / Rosetta Proof Log

Date: 2026-05-26
Workspace root inspected: `/Volumes/xcode/Synergy-Network-Projects`

## Canonical Register

Command:

```sh
rg -n "SynQ \+ aegis-pqsynq \+ Synergy-AIVM Canonical Task Register" \
  /Volumes/xcode/Synergy-Network-Projects/synq-language \
  /Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq \
  /Volumes/xcode/Synergy-Network-Projects/synergy-aivm \
  /Volumes/xcode/Synergy-Network-Projects/project-rosetta
```

Output excerpt:

```text
/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/SynQ-Aegis-AIVM-Canonical-Tasks.md:1:# SynQ + aegis-pqsynq + Synergy-AIVM Canonical Task Register
```

## Git Status

User-provided upstream GitHub repos:

- `synq-language`: `https://github.com/synergy-network-hq/synq-language`
- `aegis-pqsynq`: `https://github.com/synergy-network-hq/aegis-pqsynq`
- `synergy-aivm`: `https://github.com/synergy-network-hq/synergy-aivm`
- `project-rosetta`: `https://github.com/synergy-network-hq/project-rosetta`

Current local filesystem finding: no `.git` directory or `.git` file is present
within the four audited paths, and `git status` cannot read checkout metadata
from these local snapshots. This is recorded as a local metadata availability
gap, not as a claim that the upstream projects are not GitHub-backed.

Commands:

```sh
git -C /Volumes/xcode/Synergy-Network-Projects/synq-language status --short --branch
git -C /Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq status --short --branch
git -C /Volumes/xcode/Synergy-Network-Projects/synergy-aivm status --short --branch
git -C /Volumes/xcode/Synergy-Network-Projects/project-rosetta status --short --branch
```

Output for each path:

```text
fatal: not a git repository (or any parent up to mount point /Volumes)
Stopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).
```

Current blocker: these four local paths do not expose `.git` metadata in this filesystem snapshot.

## SynQ Language Workspace

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo fmt --check
```

Result: PASS, exit code 0.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo check --workspace --all-features --all-targets --locked
```

Output excerpt:

```text
Checking aegis-pqsynq v0.1.0 (.../synq-language/aegis-pqsynq/pqsynq)
Checking quantumvm v1.0.0 (.../synq-language/vm)
Checking compiler v0.1.0 (.../synq-language/compiler)
Checking cli v0.1.0 (.../synq-language/cli)
Finished `dev` profile [unoptimized + debuginfo] target(s)
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test --workspace --all-features --all-targets --locked
```

Output excerpts:

```text
Running tests/synq_verifier_tests.rs
running 8 tests
test wrong_chain_fails ... ok
test valid_mldsa65_call_verifies ... ok
test valid_mldsa65_deploy_verifies ... ok
test wrong_domain_fails ... ok
test transaction_dispatch_preserves_security_errors ... ok
test invalid_signature_fails ... ok
test malformed_public_key_fails ... ok
test transaction_dispatch_verifies_deploy ... ok

Running tests/canonical_payload_tests.rs
running 3 tests
test canonical_payload_bytes_are_deterministic_and_versioned ... ok
test canonical_payload_rejects_oversized_length_prefixed_fields ... ok
test signing_payload_hash_changes_with_domain_and_chain_binding ... ok

Running tests/integration_test.rs
running 6 tests
test test_compile_all_documented_examples ... ok
test test_verify_accepts_matching_bytecode_and_executes ... ok

Running tests/semantic_test.rs
running 15 tests
test semantic_accepts_mldsa_builtin_with_expected_types ... ok
test semantic_rejects_de_scoped_slhdsa_builtin ... ok

Running tests/integration_test.rs
running 7 tests
test test_mldsa_verify ... ok
test test_truncated_header_returns_error_instead_of_panicking ... ok
```

Result: PASS. The workspace test command completed with all reported tests passing.

Command:

```sh
npm run typecheck
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synq-language/sdk`

Output excerpt:

```text
> typecheck
> tsc --noEmit
```

Result: PASS, exit code 0.

Command:

```sh
npm run test:integration
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synq-language/sdk`

Output excerpt:

```text
✔ Contract deploy/call emit expected JSON-RPC envelopes
✔ QuantumVMSDK tx/balance/block RPC calls are end-to-end well-formed
✔ QuantumVMClient rejects JSON-RPC and HTTP failures
✔ PQC key APIs fail explicitly until backend is wired
ℹ tests 4
ℹ pass 4
```

Result: PASS.

## Comparative audit: aegis-pqsynq vs aegis-pqvm

Status date: 2026-05-26

Command:

```sh
find /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq -name Cargo.toml -o -name package.json
```

Output excerpt:

```text
/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/package.json
/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/aegis_crypto_core/Cargo.toml
```

Command:

```sh
find /Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq -name Cargo.toml -o -name package.json
```

Output excerpt:

```text
/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/package.json
/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/aegis_crypto_core/Cargo.toml
```

Command:

```sh
find /Users/devpup/Desktop/Testnet-Beta -path '*/target' -prune -o -name Cargo.toml -print | rg 'aegis-pqvm|pqvm|synergy-testnet-beta'
```

Output excerpt:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/Cargo.toml
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/aegis-pqvm/Cargo.toml
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/Cargo.toml
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/vendor/aegis-pqvm/Cargo.toml
/Users/devpup/Desktop/Testnet-Beta/synergy-address-engine/aegis-pqvm/Cargo.toml
```

Command:

```sh
find /Volumes/xcode/Synergy-Network-Projects -path '*/target' -prune -o -name Cargo.toml -print | rg 'aegis-pqvm|pqvm'
```

Output excerpt:

```text
/Volumes/xcode/Synergy-Network-Projects/aegis-pqvm/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/aegis-pqvm/fuzz/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/aegis-pqvm/vendor/pqcrypto-internals/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/aegis-pqvm/vendor/pqcrypto-traits/Cargo.toml
/Volumes/xcode/Synergy-Network-Projects/synergy-address-engine/aegis-pqvm/Cargo.toml
```

Command:

```sh
rg -n "aegis-pqvm|aegis-pqsynq|pqsynq|\[dependencies\]" \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/Cargo.toml \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/Cargo.toml \
  /Volumes/xcode/Synergy-Network-Projects/synq-language/Cargo.toml \
  /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/Cargo.toml
```

Output excerpt:

```text
/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/Cargo.toml:2:name = "aegis-pqsynq"
/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/Cargo.toml:11:name = "pqsynq"
/Volumes/xcode/Synergy-Network-Projects/synq-language/Cargo.toml:8:    "aegis-pqsynq/pqsynq",
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/Cargo.toml:33:aegis-pqvm = { path = "../aegis-pqvm" }
```

Command:

```sh
sed -n '1,260p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/verifier.rs
sed -n '1,260p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/payload.rs
sed -n '1,240p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/domain.rs
sed -n '1,220p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/policy.rs
sed -n '1,180p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/algorithms.rs
sed -n '1,260p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/serialization.rs
sed -n '1,220p' /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/error.rs
```

Source evidence summary:

```text
`AegisSynQVerifier` exposes verify_synq_transaction, verify_contract_deploy,
verify_contract_call, derive_synq_address, canonicalize_signing_payload,
validate_algorithm_policy, and verify_chain_domain.
`ContractDeployEnvelope` and `ContractCallEnvelope` are SynQ-specific.
`DomainTag` defines SYNQ_TX_V1, SYNQ_CONTRACT_DEPLOY_V1,
SYNQ_CONTRACT_CALL_V1, SYNQ_VALIDATOR_MESSAGE_V1, SYNQ_AIVM_RECEIPT_V1,
SYNQ_STATE_COMMITMENT_V1, SYNQ_WALLET_AUTH_V1, and
SYNQ_CROSS_CHAIN_MESSAGE_V1.
`SynQSecurityPolicy::testnet_1264_policy()` allows ML-DSA-65 for tx/deploy/call
and requires chain 1264 plus network "synergy-testnet".
`canonicalize_signing_payload` uses fixed magic, integer widths, numeric IDs,
and length-prefixed network/signer bytes.
`AegisSynQError` preserves structured codes including AEGIS-CHAIN,
AEGIS-DOMAIN, AEGIS-CANON, AEGIS-KEY, AEGIS-SIG, and AEGIS-ADDRESS.
```

Command:

```sh
sed -n '1,620p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/crypto/aegis_pqvm.rs
sed -n '1,620p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/aegis_tx_tool.rs
sed -n '1,620p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/transaction.rs
sed -n '1,260p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/dag_mempool.rs
sed -n '1,300p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/execution.rs
```

Source evidence summary:

```text
`src/crypto/aegis_pqvm.rs` defines Synergy domains including SYNERGY_TX_V1,
SYNERGY_BLOCK_V1, SYNERGY_VOTE_V1, SYNERGY_QC_V1, SYNERGY_DAG_NODE_V1,
SYNERGY_STATE_ROOT_V1, and SYNERGY_RECEIPT_ROOT_V1.
`AegisPqvmSigner` and `AegisPqvmVerifier` sign/verify chain transaction,
vote, epoch, P2P, and other Synergy domains.
`aegis_tx_tool.rs` defines `AegisTxSubmissionEnvelope` and verifies the envelope
through `AegisPqvmVerifier::verify_transaction_signature_checked`.
`transaction.rs::validate_for_admission` enforces chain/network and uses
either Aegis carrier verification or embedded PQC signature verification.
`dag_mempool.rs::admit_transaction` verifies canonical bytes and Aegis PQ
signature before DAG insertion.
`execution.rs` defines deterministic `TransactionReceipt`, state roots, and
receipt roots.
```

Command:

```sh
rg -n "SYNERGY_TESTNET_V2|require_testnet_v2|synergy_testnet_v2|CHAIN_ID|NETWORK_ID" \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src -g '*.rs'
```

Output excerpt:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs:6:pub const SYNERGY_TESTNET_V2_CHAIN_ID: u64 = 1264;
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs:7:pub const SYNERGY_TESTNET_V2_NETWORK_ID: &str = "synergy-testnet-v2";
```

Command:

```sh
rg -n "AIVM|synq_|deploy|call|sendTransaction|submitAegis|Receipt|receipt|estimateGas|estimatePq|verifyPayload|getSecurityPolicy|Contract" \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/rpc/rpc_server.rs \
  /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src -g '*.rs'
```

Output excerpt:

```text
src/rpc/rpc_server.rs:1545:        "synergy_sendTransaction" => {
src/rpc/rpc_server.rs:1612:        "synergy_submitAegisTransaction" | "synergy_submitAegisDagTransaction" => {
src/rpc/rpc_server.rs:2430:        // TEMPORARILY DISABLED:         // AIVM - Artificial Intelligence Virtual Machine Methods
src/rpc/rpc_server.rs:2932:        "synergy_getTransactionReceipt" => {
src/rpc/rpc_server.rs:3119:        "synergy_call" => {
src/rpc/rpc_server.rs:3156:        "synergy_estimateGas" => {
src/rpc/rpc_server.rs:3184:        "synergy_getReceipt" => transaction_receipt_json(&params, chain),
```

Command:

```sh
sed -n '150,270p' /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synq/compiler.rs
```

Source evidence summary:

```text
The local Testnet-Beta SynQ compiler prototype generates PQC-related signatures
locally and Solidity compatibility text locally. It does not call `aegis-pqsynq`.
This is duplicate/prototype behavior that should not become the canonical
deploy/call security policy.
```

Document created:

```text
/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/architecture/aegis-pqsynq-vs-aegis-pqvm-integration.md
```

Decision recorded:

```text
Both modules are needed. Current source-proven architecture is Model D:
Testnet-Beta uses aegis-pqvm for chain/node admission and does not yet call
aegis-pqsynq. Recommended target is Model B: node/AIVM calls aegis-pqsynq for
inner SynQ deploy/call payload verification and keeps aegis-pqvm as the outer
blockchain transaction/DAG/VM admission owner.
```

Verification commands:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo fmt --all --check
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synq-language`

Result: PASS, exit code 0.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test -p aegis-pqsynq --test synq_verifier_tests --locked
```

Output excerpt:

```text
running 17 tests
test valid_mldsa65_deploy_verifies ... ok
test valid_mldsa65_call_verifies ... ok
test wrong_chain_fails ... ok
test wrong_domain_fails ... ok
test invalid_signature_fails ... ok
test transaction_dispatch_preserves_security_errors ... ok
test result: ok. 17 passed; 0 failed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-pqvm-audit cargo test --manifest-path /Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/aegis-pqvm/Cargo.toml --test integrations_dispatch --test vm_validation --test security_smoke --locked
```

Output excerpt:

```text
Running tests/integrations_dispatch.rs
running 6 tests
test mldsa_verify_detached_returns_true_then_false_on_tamper ... ok
test fndsa_verify_detached_returns_true ... ok
test result: ok. 6 passed

Running tests/security_smoke.rs
running 3 tests
test mldsa_smoke_tamper_message_or_signature_fails ... ok
test fndsa_smoke_tamper_message_or_signature_fails ... ok
test result: ok. 3 passed

Running tests/vm_validation.rs
running 15 tests
test evm_precompile_rejects_invalid_magic ... ok
test substrate_dispatch_rejects_invalid_payload ... ok
test cosmwasm_call_accepts_bound_payload ... ok
test result: ok. 15 passed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-testnet-audit cargo test -p synergy-testnet aegis_tx_tool::tests -- --nocapture
```

Result: BLOCKED before tests by local disk capacity, not by a Rust assertion failure.

Output excerpt:

```text
error: failed to write /Volumes/xcode/cargo-target-testnet-audit/debug/deps/libreqwest-...rmeta: No space left on device (os error 28)
warning: pqcrypto-falcon@0.3.0: ar: .../libfalcon-1024_aarch64.a: No space left on device
error: could not compile `reqwest` (lib) due to 1 previous error
error: could not compile `hickory-resolver` (lib) due to 1 previous error
error: could not compile `chrono` (lib) due to 1 previous error
```

Command:

```sh
df -h /Volumes/xcode /tmp /Users/devpup
```

Output excerpt:

```text
Filesystem      Size    Used   Avail Capacity
/dev/disk7s1   237Gi   237Gi    32Mi   100%   /Volumes/xcode
/dev/disk3s1   228Gi   177Gi   5.1Gi    98%   /System/Volumes/Data
```

Final git status command:

```sh
git status --short --branch
```

Output excerpt for `/Volumes/xcode/Synergy-Network-Projects/project-rosetta`:

```text
## main...origin/main
 M crates/rosetta-verification/src/lib.rs
 M crates/rosetta-verification/src/synergy.rs
 M docs/synergy-testnet-integration.md
```

Output excerpt for `/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta`:

```text
## main...origin/main
 M src/consensus/consensus_algorithm.rs
?? scripts/testnet/incident-install-runtime-only-v13.sh
?? scripts/testnet/incident-relayer1-build-recovery-plan.sh
?? scripts/testnet/incident-val1-build-recovery-plan.sh
?? scripts/testnet/incident-val5-build-recovery-plan.sh
```

Note: the modified consensus file and untracked incident scripts were not
created or edited during this comparative audit.

## TESTNET-Beta Local Source Inspection

Source root inspected:

```text
/Users/devpup/Desktop/Testnet-Beta
```

Implementation source of truth inspected:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta
```

Directory inventory:

```text
Git roots found under /Users/devpup/Desktop/Testnet-Beta:
synergy-prism
synergy-horizon
synergy-testnet-beta/node-control-panel
synergy-testnet-beta
synergy-address-engine
synergy-learn
explorer-app
synergy-vault
meme-launchpad
synergy-quest
synergy-forge
synq-language
```

Chain constants discovered:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs
pub const SYNERGY_TESTNET_V2_CHAIN_ID: u64 = 1264;
pub const SYNERGY_TESTNET_V2_NETWORK_ID: &str = "synergy-testnet-v2";
```

RPC methods discovered from
`/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/rpc/rpc_server.rs`:

```text
Public read examples:
synergy_chainId
synergy_networkId
synergy_genesisHash
synergy_protocolVersion
synergy_syncing
synergy_getHealth
synergy_getReadiness
synergy_getPeers
synergy_getAegisStatus
synergy_getAegisCapabilities
synergy_verifyAegisTransaction
synergy_getDagStatus
synergy_getDagFrontier
synergy_getDagGraph
synergy_getDagDependencies
synergy_getDagTxOrderRoot
synergy_getTransactionReceipt
synergy_getReceipt
synergy_getBlockReceipts
synergy_getLogs
synergy_getCode
synergy_getStorageAt

Public client examples:
synergy_simulateTransaction
synergy_sendTransaction
synergy_submitAegisTransaction
synergy_submitAegisTransactionBatch
synergy_submitAegisDagTransaction
synergy_submitAegisDagTransactionBatch
synergy_call
synergy_estimateGas
synergy_registerSynID
```

Transaction envelope sources:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/transaction.rs
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/rpc/rpc_server.rs
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/aegis_tx_tool.rs
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/synergy_types.rs
```

Receipt shapes discovered:

```text
synergy_getReceipt fields:
transactionHash, transactionIndex, blockHash, blockNumber, from, to,
cumulativeGasUsed, gasUsed, effectiveGasPrice, feeCharged, feeCollector,
status, logs, chain

synergy_getTransactionReceipt fields:
transactionHash, transactionIndex, blockHash, blockNumber, from, to,
cumulativeGasUsed, gasUsed, effectiveGasPrice, status, logs, logsBloom,
contractAddress

chain fields:
name, chain_id, chain_id_hex, network_id, genesis_hash
```

Validation flow discovered:

```text
synergy_sendTransaction -> normalize_rpc_transaction -> chainId check ->
Transaction::validate_for_admission -> embedded PQC verification or legacy
Aegis carrier verification -> TX_POOL queue -> optional P2P broadcast

synergy_submitAegisTransaction / synergy_submitAegisDagTransaction ->
AegisTxSubmissionEnvelope -> legacy_transaction_from_aegis_envelope ->
chain check -> canonical transaction bytes -> Aegis PQVM SYNERGY_TX_V1 hash ->
TX_POOL queue -> optional P2P broadcast
```

AIVM status discovered:

```text
/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/aivm/runtime.rs
defines AIVMExecutionContext, AIVMExecutionResult, AIVMContract, and AIVMRuntime.

/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta/src/rpc/rpc_server.rs
contains synergy_deployAIVMContract and synergy_executeAIVMContract handlers
commented out as TEMPORARILY DISABLED.
```

Artifact created:

```text
/Volumes/xcode/Synergy-Network-Projects/synq-language/docs/integration/testnet-beta-source-inventory-2026-05-26.md
```

## Project Rosetta Real Synergy Receipt Mapping

Files changed:

```text
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/crates/rosetta-core/src/domain.rs
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/crates/rosetta-core/src/lib.rs
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/crates/rosetta-verification/src/lib.rs
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/crates/rosetta-verification/src/synergy.rs
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/docs/synergy-testnet-integration.md
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/sdk/typescript/src/route.ts
/Users/devpup/Desktop/Testnet-Beta/project-rosetta/sdk/typescript/test/synergy-domain.test.ts
/Volumes/xcode/Synergy-Network-Projects/project-rosetta/crates/rosetta-verification/src/lib.rs
/Volumes/xcode/Synergy-Network-Projects/project-rosetta/crates/rosetta-verification/src/synergy.rs
/Volumes/xcode/Synergy-Network-Projects/project-rosetta/docs/synergy-testnet-integration.md
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-canon cargo test -p rosetta-verification synergy::tests -- --nocapture
```

Workdir:
`/Volumes/xcode/Synergy-Network-Projects/project-rosetta`

Output excerpt:

```text
running 9 tests
test synergy::tests::real_synergy_get_receipt_shape_maps_to_rosetta_receipt ... ok
test synergy::tests::rpc_receipt_hash_is_deterministic ... ok
test synergy::tests::mock_synergy_route_scenario_outputs_deterministic_index_record ... ok
test result: ok. 9 passed; 0 failed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-testnet-user cargo test -p rosetta-verification synergy::tests -- --nocapture
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/project-rosetta`

Output excerpt:

```text
running 9 tests
test synergy::tests::real_synergy_get_receipt_shape_maps_to_rosetta_receipt ... ok
test synergy::tests::rpc_receipt_hash_is_deterministic ... ok
test synergy::tests::mock_synergy_route_scenario_outputs_deterministic_index_record ... ok
test result: ok. 9 passed; 0 failed
```

Command:

```sh
corepack pnpm --filter @synergy/rosetta-sdk test
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/project-rosetta`

Output excerpt:

```text
Test Files  4 passed (4)
Tests  5 passed (5)
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-canon cargo clippy -p rosetta-verification --all-targets -- -D warnings
```

Workdir:
`/Volumes/xcode/Synergy-Network-Projects/project-rosetta`

Result: PASS.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-testnet-user cargo clippy -p rosetta-verification --all-targets -- -D warnings
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/project-rosetta`

Result: PASS.

## TESTNET-Beta Targeted Rust Verification

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-testnet-beta-exec cargo test -p synergy-testnet execution::tests -- --nocapture
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta`

Output excerpt:

```text
running 3 tests
test execution::tests::missing_or_altered_authorization_context_fails_closed ... ok
test execution::tests::failed_receipt_is_deterministic_and_conflicts_execute_in_order ... ok
test execution::tests::same_block_executed_repeatedly_produces_same_state_root ... ok
test result: ok. 3 passed; 0 failed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-testnet-beta-exec cargo test -p synergy-testnet launch_ -- --nocapture
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta`

Output excerpt:

```text
running 9 tests
test rpc::rpc_server::tests::public_gateway_allows_launch_aegis_submit_methods ... ok
test rpc::rpc_server::tests::public_gateway_allows_launch_read_rpc_surface ... ok
test rpc::rpc_server::tests::launch_identity_rpc_reports_canonical_testnet_identity ... ok
test result: ok. 9 passed; 0 failed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-testnet-beta-exec cargo test -p synergy-testnet aegis_tx_tool::tests -- --nocapture
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta`

Output excerpt:

```text
running 4 tests
test aegis_tx_tool::tests::altered_transaction_bytes_fail_aegis_verification ... ok
test aegis_tx_tool::tests::real_aegis_transaction_key_signs_verifies_and_admits_to_dag ... ok
test aegis_tx_tool::tests::aegis_submission_envelope_rejects_wrong_chain_and_carrier_tampering ... ok
test aegis_tx_tool::tests::fixture_uses_dependencies_and_no_wallet_cli_path ... ok
test result: ok. 4 passed; 0 failed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-testnet-beta-exec cargo test -p synergy-testnet transaction::tests::admission_requires_testnet_context_and_real_pqc_signature -- --nocapture
```

Workdir:
`/Users/devpup/Desktop/Testnet-Beta/synergy-testnet-beta`

Output excerpt:

```text
running 1 test
test transaction::tests::admission_requires_testnet_context_and_real_pqc_signature ... ok
test result: ok. 1 passed; 0 failed
```

Note: these commands emitted existing dead-code warnings in the
`synergy-testnet` crate. No test failed.

## Local RPC Port Probe

Command:

```sh
lsof -nP -iTCP:5640 -sTCP:LISTEN
```

Result: no listener, exit code 1.

Command:

```sh
lsof -nP -iTCP:5641 -sTCP:LISTEN
```

Result: no listener, exit code 1.

Command:

```sh
curl -sS --max-time 3 -H 'Content-Type: application/json' --data '{"jsonrpc":"2.0","id":1,"method":"synergy_chainId","params":[]}' http://127.0.0.1:5640
```

Output:

```text
curl: (7) Failed to connect to 127.0.0.1 port 5640 after 0 ms: Couldn't connect to server
```

Command:

```sh
curl -sS --max-time 3 -H 'Content-Type: application/json' --data '{"jsonrpc":"2.0","id":1,"method":"synergy_chainId","params":[]}' http://127.0.0.1:5641
```

Output:

```text
curl: (7) Failed to connect to 127.0.0.1 port 5641 after 0 ms: Couldn't connect to server
```

Conclusion: no local RPC endpoint was already listening on qRPC ports 5640 or
5641. I did not start an ad hoc node/validator, so `NET-007` remains partial
with source-backed RPC matrix proof but no active local request/response proof.

## Follow-Up Canonical Register Work

Command:

```sh
rg -n "Canonical status|canonical register|SynQ-Aegis-AIVM-Canonical" checklist.md INTEGRATION_STATUS.md docs/PQSynQ-Completion-Execution-Plan.md docs/SynQ-Project-Status-and-Execution-Backlog.md docs/SynQ-Security-Audit-Manual.md docs/management/Definition-of-Done.md docs/management/SynQ-Release-Milestones.md docs/management/Weekly-Status-Template.md
```

Output excerpt:

```text
checklist.md:3:> Canonical status note (2026-05-26): this file is a historical planning
INTEGRATION_STATUS.md:3:> Canonical status note (2026-05-26): this file is a historical integration
docs/PQSynQ-Completion-Execution-Plan.md:3:> Canonical status note (2026-05-26): this file is a historical execution plan.
docs/SynQ-Project-Status-and-Execution-Backlog.md:3:> Canonical status note (2026-05-26): this backlog is superseded by
docs/SynQ-Security-Audit-Manual.md:3:> Canonical status note (2026-05-26): this manual remains useful security
docs/management/Definition-of-Done.md:3:> Canonical status note (2026-05-26): this DoD remains policy guidance.
docs/management/SynQ-Release-Milestones.md:3:> Canonical status note (2026-05-26): this release plan is a historical planning
docs/management/Weekly-Status-Template.md:3:> Canonical status note (2026-05-26): this template is for reporting cadence
```

Result: PASS. Old checklist/status/planning files now point to the canonical register or explicitly state they are historical/non-authoritative for completion claims.

## Aegis SynQ Verifier Expansion

Changed files:

- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/src/signature.rs`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/synq_verifier_tests.rs`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/synq_deploy_vector_tests.rs`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_valid_deploy.json`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_invalid_signature.json`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_wrong_chain.json`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_wrong_domain.json`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/examples/generate_synq_verifier_vectors.rs`
- `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq/examples/synq_deploy_call_verifier.rs`

Standalone mirror copies were also updated under:

- `/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq/`

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo fmt --check
```

Result: PASS.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test -p aegis-pqsynq --test synq_verifier_tests --test synq_deploy_vector_tests --locked
```

Output excerpt:

```text
Running tests/synq_deploy_vector_tests.rs
running 1 test
test ml_dsa_65_deploy_vectors_replay ... ok
test result: ok. 1 passed

Running tests/synq_verifier_tests.rs
running 17 tests
test valid_mldsa65_deploy_verifies ... ok
test valid_mldsa65_call_verifies ... ok
test invalid_signature_fails ... ok
test malformed_public_key_fails ... ok
test malformed_signature_fails ... ok
test wrong_chain_fails ... ok
test wrong_domain_fails ... ok
test wrong_algorithm_fails ... ok
test wrong_signer_fails ... ok
test expired_payload_fails ... ok
test oversized_public_key_fails ... ok
test oversized_signature_fails ... ok
test deploy_domain_cannot_be_replayed_as_call ... ok
test call_payload_cannot_be_replayed_as_wallet_auth ... ok
test testnet_payload_cannot_be_replayed_as_mainnet ... ok
test transaction_dispatch_preserves_security_errors ... ok
test transaction_dispatch_verifies_deploy ... ok
test result: ok. 17 passed
```

Result: PASS.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo run -p aegis-pqsynq --example synq_deploy_call_verifier --locked
```

Output excerpt:

```text
chain_id=1264
network=synergy-testnet
address=tsynq10104f00102a3a9149fe99438455b9e633aedd3441b835a6901fc89d2b72772b2c4848ac80cd6a1a411
deploy=verified
call=verified
```

Result: PASS.

Command:

```sh
rg -n "secret|private|sk|seed" aegis-pqsynq/pqsynq/tests/vectors/ml_dsa_65_*.json || true
```

Output: no matches.

Result: PASS. The new ML-DSA-65 deploy vector fixtures do not contain private-key or seed fields.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test -p aegis-pqsynq --all-features --all-targets --locked
```

Output excerpt:

```text
Running tests/synq_deploy_vector_tests.rs
test ml_dsa_65_deploy_vectors_replay ... ok

Running tests/synq_verifier_tests.rs
running 17 tests
test result: ok. 17 passed

Running unittests examples/synq_deploy_call_verifier.rs
test result: ok. 0 passed
```

Result: PASS. Shell startup emitted two `/tmp` space warnings from `rbenv-init`, but the Cargo command completed successfully with exit code 0 using `TMPDIR=/Volumes/xcode/tmp`.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test --workspace --all-features --all-targets --locked
```

Output excerpt:

```text
Running tests/synq_deploy_vector_tests.rs
test ml_dsa_65_deploy_vectors_replay ... ok
Running tests/synq_verifier_tests.rs
test result: ok. 17 passed
Running tests/integration_test.rs
test result: ok. 6 passed
Running tests/semantic_test.rs
test result: ok. 15 passed
Running tests/integration_test.rs
test result: ok. 7 passed
```

Result: PASS.

## Final Git Status Recheck

Commands:

```sh
git rev-parse --show-toplevel 2>&1 || true
git status --short --branch 2>&1 || true
```

Results:

- `/Volumes/xcode/Synergy-Network-Projects/synq-language`: local Git metadata unavailable; command returned `fatal: not a git repository`.
- `/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq`: local Git metadata unavailable; command returned `fatal: not a git repository`.
- `/Volumes/xcode/Synergy-Network-Projects/synergy-aivm`: local Git metadata unavailable; command returned `fatal: not a git repository`.
- `/Volumes/xcode/Synergy-Network-Projects/project-rosetta`: Git root `/Volumes/xcode/Synergy-Network-Projects/project-rosetta`; status `## main...origin/main` with no dirty entries.

## aegis-pqsynq

Active buildable crate: `/Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq`

Standalone mirror: `/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq`

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-synq-canon cargo test -p aegis-pqsynq --all-features --all-targets --locked
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synq-language`

Output excerpts:

```text
Running tests/basic_tests.rs
running 3 tests
test test_mlkem768_basic ... ok
test test_mldsa65_basic ... ok
test test_fndsa512_basic ... ok

Running tests/kat_tests.rs
running 5 tests
test test_mldsa_known_message_matrix ... ok
test test_hqckem_size_and_roundtrip_matrix ... ok

Running tests/nist_vector_replay_tests.rs
running 4 tests
test test_nist_fndsa_replay_vectors ... ok
test test_nist_hqckem_replay_vectors ... ok
test test_nist_mldsa_replay_vectors ... ok
test test_nist_mlkem_replay_vectors ... ok

Running tests/synq_verifier_tests.rs
running 8 tests
test transaction_dispatch_preserves_security_errors ... ok
test transaction_dispatch_verifies_deploy ... ok
test valid_mldsa65_deploy_verifies ... ok
test valid_mldsa65_call_verifies ... ok

Running benches/pqc_benchmarks.rs
Testing ML-DSA Performance/ML-DSA-65_keygen/
Success
Testing ML-DSA Performance/ML-DSA-65_sign/
Success
Testing ML-DSA Performance/ML-DSA-65_verify/
Success
```

Result: PASS.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-aegis-standalone-canon \
  cargo test --manifest-path /Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq/Cargo.toml --test canonical_payload_tests --locked
```

Output:

```text
error: failed to parse manifest at `/Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq/Cargo.toml`

Caused by:
  error inheriting `pqrust-fndsa` from workspace root manifest's `workspace.dependencies.pqrust-fndsa`

Caused by:
  failed to find a workspace root
```

Result: BLOCKED for standalone mirror until a real workspace root is restored. Source additions were mirrored; the active embedded workspace is the build-proven copy.

Command:

```sh
diff -qr /Volumes/xcode/Synergy-Network-Projects/synq-language/aegis-pqsynq/pqsynq \
  /Volumes/xcode/Synergy-Network-Projects/aegis-pqsynq/aegis-pqsynq/pqsynq
```

Output excerpt:

```text
Files .../tests/nist_vector_replay_tests.rs and .../tests/nist_vector_replay_tests.rs differ
```

## Synergy-AIVM

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-aivm-core-canon cargo test
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synergy-aivm/runtime/aivm-core`

Output excerpt:

```text
running 3 tests
test execution::tests::executes_synq_bytecode_artifacts ... ok
test vm::wasm_runner::tests::loads_minimal_wasm_module ... ok
test execution::tests::accepts_wasm_artifacts ... ok
test result: ok. 3 passed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-aivm-node-canon cargo test
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synergy-aivm/runtime/aivm-node`

Output excerpt:

```text
running 0 tests
test result: ok. 0 passed
```

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-aivm-verifier-canon cargo test
```

Workdir: `/Volumes/xcode/Synergy-Network-Projects/synergy-aivm/verifier/verifier-core`

Output excerpt:

```text
running 2 tests
test attestation::tests::detects_incomplete_reports ... ok
test verifier::tests::incomplete_attestation_is_not_trusted ... ok
test result: ok. 2 passed
```

## Project Rosetta

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-canon cargo fmt --check
```

Result: PASS, exit code 0.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-canon cargo test --workspace
```

Output excerpts:

```text
Running unittests src/lib.rs (.../rosetta_verification-...)
running 10 tests
test synergy::tests::mock_synergy_receipt_verifier_consumes_chain_1264_receipts ... ok
test synergy::tests::receipt_hash_is_deterministic ... ok
test synergy::tests::unfinalized_receipt_is_rejected ... ok
test synergy::tests::bad_receipt_hash_is_rejected ... ok
test synergy::tests::wrong_chain_is_rejected ... ok

Running unittests src/lib.rs (.../rosetta_core-...)
running 3 tests
test domain::tests::synergy_testnet_domain_is_chain_1264 ... ok

Running unittests src/lib.rs (.../rosetta_settlement-...)
running 14 tests
test successful_escrow_swap ... ok
```

Result: PASS.

Command:

```sh
TMPDIR=/Volumes/xcode/tmp CARGO_TARGET_DIR=/Volumes/xcode/cargo-target-rosetta-canon cargo clippy --workspace --all-targets -- -D warnings
```

Output excerpt:

```text
Checking rosetta-core v0.1.0
Checking rosetta-verification v0.1.0
Checking rosetta-cli v0.1.0
Finished `dev` profile [unoptimized + debuginfo]
```

Result: PASS.

Command:

```sh
corepack pnpm --filter @synergy/rosetta-sdk typecheck
```

Output excerpt:

```text
> @synergy/rosetta-sdk@0.1.0 typecheck .../sdk/typescript
> tsc --noEmit
```

Result: PASS.

Command:

```sh
corepack pnpm --filter @synergy/rosetta-sdk test
```

Output excerpt:

```text
Test Files  4 passed (4)
Tests  5 passed (5)
```

Result: PASS.
